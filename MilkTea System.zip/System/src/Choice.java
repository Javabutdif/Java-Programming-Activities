
public class Choice {
	
	
	public void choice1(int choice) {
		MilkTea mm = new MilkTea();
		
		switch(choice) {
		case 1 -> mm.addMilkTea("Milk Tea");
		case 2 -> mm.addMilkTea("Coffee Milk Tea");
		case 3 -> mm.addMilkTea("Black Tea");
		case 4 -> mm.addMilkTea("Booba Tea");
		case 5 -> mm.addMilkTea("Condense Tea");
		}
	}

	

}
