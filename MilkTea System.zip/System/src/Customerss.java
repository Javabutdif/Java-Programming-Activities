import java.util.LinkedList;
import java.util.Queue;
public class Customerss {

	static Queue<String> customerss = new LinkedList<String>(); 
	
	public Queue<String> getCust(){
		
		customerss.add("Jude");
		customerss.add("Brandon");
		customerss.add("Kyle");
		customerss.add("Gilyan");
		customerss.add("Abi");
		customerss.add("Rennel");
		customerss.add("Elic");
		
		
		return customerss;
	}
}
