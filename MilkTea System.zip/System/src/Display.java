import java.util.Random;

public class Display {
	static Random rand = new Random();
	Display(){
		  System.out.println("Welcome to Kyle Booba Milk Tea");
	      System.out.println("==============================");
	      System.out.println("==========|M E N U|===========");
	      System.out.println("[1] Milk Tea        | Medium [89] || Large 99");
	      System.out.println("[2] Coffee Milk Tea | Medium [89] || Large 99");
	      System.out.println("[3] Black Tea       | Medium [89] || Large 99");
	      System.out.println("[4] Booba Tea       | Medium [89] || Large 99");
	      System.out.println("[5] Condense Tea    | Medium [89] || Large 99");
	      System.out.println("==============================");
	}
	
	public String getRef() {
		String name = "";
		
		for(int i = 0; i < 9; i++) {
			name += rand.nextInt(10);
		}
		
		
		return name;
	}
	
	//Sa money rani sa customer na naka condition. Automatic rani kay kapoy type HAHAH
	public int getMoney(int money) {
		int total = 0;
		int x =0;
		
		int[] money1 = {100,200,500,1000,1500,2000,2500,3000,4000,5000,6000};
		
		do {
			if(money1[x] > money) {
				total =money1[x];
				break;
				
			}
			x++;
		}while(x < money1.length);
		x = 0;
		
		return total;
		
	
		
		
	}
	
	
}
