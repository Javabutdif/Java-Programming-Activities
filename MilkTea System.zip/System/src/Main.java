import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Random;

public class Main {
	 //Global Declaration
	static int term = 0;
	static Scanner console = new Scanner(System.in);
	static MilkTea mm = new MilkTea();
	static Choice  ch = new Choice();
	static Customerss cust = new Customerss();
	static Queue<String> customers = new LinkedList<String>();
	static Random rand = new Random();
	static ReferenceOrders reff = new ReferenceOrders();
	
	//Main Method
	public static void main(String[] args) throws InterruptedException {
		int total = 0;
		int money = 0;
		int money1 = 0;
		int choice = 0;
		int j = 0;
		int add = 0;
		int totalMoney =0;
	
		Account acc = new Account();
		Display display = new Display();
		customers.addAll(cust.getCust());
		
		
	while(j < 5) {
		acc.setName(customers.poll());
			
			
			System.out.println("Customer Name: " + acc.getName());
		for(int i = 0; term != 1;i++ ) {
			Thread.sleep(2000);
			choice = getChoice();
			System.out.println("Enter Milk Tea: " + choice );
			ch.choice1(choice);
			char size = getSize();
			System.out.println("Enter Size [M] | [L]: " + size);
			money = size == 'M' || size == 'm' ? 89 : 99;
			add = getAdd();
			System.out.println("Enter number of milktea : " + add);
			money1 = money1 + (money * add) ;
			
			char cond = getCondition();
			System.out.println("Do you want to add again? [Y] | [N]: " + cond);
			term = cond == 'Y' ||cond == 'y' ? 0 : 1; 
		
		}
		term = 0;
			
		System.out.println();
		System.out.println("Customer: " + acc.getName());
		System.out.println("==============================");
		System.out.println("Your orders: " + mm.getM());
		System.out.println("==============================");
		System.out.println("The Total will be: " + money1);
		System.out.println();
		
		while(totalMoney == 0) {
		totalMoney = display.getMoney(money1);
		
		total = totalMoney > money1 ? totalMoney-money1 : 0;
		}
		
		System.out.println("Customer Money: " + totalMoney);
		System.out.println();
		System.out.println("===============RECEIPT===============");
		System.out.println("Customer: " + acc.getName());
		System.out.println("Orders: " + mm.getM());
		System.out.println();
		System.out.println("Total: " + money1);
		System.out.println("Change: " + total);
		System.out.println("=====================================");
		String reference = display.getRef();
		ReferenceOrders.setRef(reference);
		System.out.println("Reference number: " + reference);
		System.out.println("==============================");
		System.out.println();
		System.out.println();
		j++;
		total = 0;
		mm.removedList();
		totalMoney = 0;
		money1 =0;
		
	}
	System.out.println();
	System.out.println();
	System.out.println("==============================");
	System.out.println("Reference Numbers Orders");
	System.out.println(reff.getRef());
	}
	
	public static int getChoice() {
		int[] num = {1,2,3,4,5};
		
		return num[rand.nextInt(num.length)];
	}
	public static char getSize() {
		char[] choice = {'M','m','L','l'};
		
		return choice[rand.nextInt(choice.length)];
		
	}
	public static int getAdd() {
		int[] num = {1,2,3,4,5};
		
		return num[rand.nextInt(num.length)];
		
	}
	public static char getCondition() {
		char[] choice = {'Y','y','N','n'};
		
		 return choice[rand.nextInt(choice.length)];
	}
	

}
