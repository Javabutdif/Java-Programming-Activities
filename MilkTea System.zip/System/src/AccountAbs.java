
public interface AccountAbs {
	String getName();
	void setName(String name);


}
