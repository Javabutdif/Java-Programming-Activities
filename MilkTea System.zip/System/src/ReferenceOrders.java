import java.util.LinkedList;

public class ReferenceOrders {
	static LinkedList<String> ref = new LinkedList<String>();
	
	public static void setRef(String reff) {
		ref.add(reff);
	}
	public LinkedList<String> getRef(){
		return ref;
	}
}
