import java.util.LinkedList;
public class MilkTea {
	
	static LinkedList<String> milkTea = new LinkedList<String>();
	
	public void addMilkTea(String name) {
		milkTea.offer(name);
	}
	public LinkedList<String> getM(){
		
		return milkTea;
	}
	public void removedList() {
		milkTea.removeAll(milkTea);
	}
	
}
